"""
Created by organization iNeuron Intelligence Private Limited
Created date is (dd-mm-yyyy): 06-05-2022
"""
from app_config.configuration import AppConfiguration
from app_config.configuration import DATASET_SCHEMA_DOMAIN_VALUE_KEY
from app_config.configuration import DATASET_SCHEMA_TARGET_COLUMN_KEY  
from app_config.configuration import DATASET_SCHEMA_COLUMNS_KEY