"""
Created by organization iNeuron Intelligence Private Limited
Created date is (dd-mm-yyyy): 06-05-2022
"""

from app_pipeline.training_pipeline import TrainingPipeline