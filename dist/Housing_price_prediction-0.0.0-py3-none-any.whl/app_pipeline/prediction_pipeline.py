from app_logger import logging
from app_exception import AppException


class PredictionPipeline:
    pass