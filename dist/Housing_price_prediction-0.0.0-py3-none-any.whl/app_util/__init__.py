"""
Created by organization iNeuron Intelligence Private Limited
Created date is (dd-mm-yyyy): 06-05-2022
"""


from app_util.util import read_yaml_file,load_object,save_object,write_yaml_file